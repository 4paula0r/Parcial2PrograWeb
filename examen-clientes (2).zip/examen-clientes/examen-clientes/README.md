# Listado de clientes (React + Express + SQL Server)

React (Vite) -> fetch -> Express (API) -> SQL Server (EmpresaDB)

## Orden para ejecutar
1. SQL Server: ejecutar `database/esquema.sql`
2. Backend:  cd backend  -> npm install -> node server.js   (puerto 3000)
3. Frontend: cd frontend -> npm install -> npm run dev       (puerto 5173)

## Estructura
- `database/`  script SQL de la tabla Clientes
- `backend/`   API Express (GET /api/clientes)
- `frontend/`  app React con tabla y buscador
