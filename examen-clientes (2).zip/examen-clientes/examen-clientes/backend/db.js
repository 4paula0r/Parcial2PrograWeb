const sql = require("mssql");

const config = {
    user: "examen_user",
    password: "Examen123!",
    server: "localhost",
    database: "EmpresaDB",
    options: {
        instanceName: "SQLEXPRESS",
        encrypt: false,
        trustServerCertificate: true
    }
};

const poolPromise = new sql.ConnectionPool(config)
    .connect()
    .then(pool => {
        console.log("Conectado correctamente a SQL Server");
        return pool;
    })
    .catch(error => {
        console.error("Error conectando a SQL Server:", error.message);
        throw error;
    });

module.exports = { sql, poolPromise };