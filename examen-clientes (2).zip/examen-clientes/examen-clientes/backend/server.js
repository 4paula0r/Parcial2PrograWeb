const express = require("express");
const cors = require("cors");
const { poolPromise } = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

// GET: consultar todos los clientes
app.get("/api/clientes", async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request().query(`
            SELECT IdCliente, Nombre, Correo, Telefono, Ciudad
            FROM Clientes
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error("Error al consultar:", error.message);
        res.status(500).json({
            mensaje: "Error al consultar los clientes",
            error: error.message
        });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor ejecutandose en http://localhost:${PORT}`);
});
