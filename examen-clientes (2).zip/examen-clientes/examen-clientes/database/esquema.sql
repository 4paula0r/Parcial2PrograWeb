-- =====================================================
-- Base de datos: EmpresaDB  
-- =====================================================
IF DB_ID('EmpresaDB') IS NULL
    CREATE DATABASE EmpresaDB;
GO
USE EmpresaDB;
GO

DROP TABLE IF EXISTS Clientes;
GO

CREATE TABLE Clientes (
    IdCliente     INT IDENTITY(1,1) PRIMARY KEY,   -- clave primaria autoincremental
    Nombre        VARCHAR(100) NOT NULL,
    Correo        VARCHAR(100) NOT NULL UNIQUE,
    Telefono      VARCHAR(12),
    Ciudad        VARCHAR(50),
    FechaRegistro DATETIME NOT NULL DEFAULT GETDATE()
);
GO

INSERT INTO Clientes (Nombre, Correo, Telefono, Ciudad) VALUES
('María López',     'maria.lopez@correo.com',   '5555-1001', 'Guatemala'),
('Carlos Méndez',   'carlos.mendez@correo.com', '5555-1002', 'Antigua Guatemala'),
('Lucía Hernández', 'lucia.hdz@correo.com',     '5555-1003', 'Quetzaltenango'),
('José Pérez',      'jose.perez@correo.com',    '5555-1004', 'Escuintla'),
('Andrea Castillo', 'andrea.c@correo.com',      '5555-1005', 'Cobán'),
('Diego Morales',   'diego.morales@correo.com', '5555-1006', 'Guatemala');
GO

SELECT * FROM Clientes;
