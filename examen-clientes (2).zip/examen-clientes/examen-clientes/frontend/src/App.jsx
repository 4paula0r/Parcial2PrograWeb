import Clientes from './pages/Clientes'

function App() {
  return (
    <div className="app">
      <header>
        <h1>Sistema de clientes</h1>
      </header>
      <main>
        <Clientes />
      </main>
    </div>
  )
}

export default App
