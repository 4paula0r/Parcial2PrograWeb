// Componente que dibuja la tabla. Solo recibe la lista por PROPS y la muestra.
function TablaClientes({ clientes }) {
  if (clientes.length === 0) {
    return <p>No se encontraron clientes.</p>
  }

  return (
    <div className="tabla-scroll">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Teléfono</th>
            <th>Ciudad</th>
          </tr>
        </thead>
        <tbody>
          {clientes.map((c) => (
            <tr key={c.IdCliente}>
              <td>{c.IdCliente}</td>
              <td>{c.Nombre}</td>
              <td>{c.Correo}</td>
              <td>{c.Telefono}</td>
              <td>{c.Ciudad}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default TablaClientes
