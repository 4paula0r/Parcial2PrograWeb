// Componente reutilizable de búsqueda.
// Recibe por PROPS el valor actual y la función que lo actualiza (el state vive en el padre).
function Buscador({ valor, onCambio, placeholder }) {
  return (
    <input
      className="buscador"
      type="text"
      placeholder={placeholder}
      value={valor}
      onChange={(e) => onCambio(e.target.value)}
    />
  )
}

export default Buscador
