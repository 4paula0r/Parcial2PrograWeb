import { useEffect, useState } from 'react'
import Buscador from '../components/Buscador'
import TablaClientes from '../components/TablaClientes'

const API_URL = 'http://localhost:3000/api/clientes'

function Clientes() {

  const [clientes, setClientes] = useState([])
  const [busqueda, setBusqueda] = useState('')
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetch(API_URL)
      .then((respuesta) => {
        if (!respuesta.ok) throw new Error('Error al consultar la API')
        return respuesta.json()
      })
      .then((datos) => {
        setClientes(datos)
        setCargando(false)
      })
      .catch(() => {
        setError('No se pudieron cargar los clientes. ¿Está corriendo el backend?')
        setCargando(false)
      })
  }, [])

  const texto = busqueda.toLowerCase()
  const filtrados = clientes.filter(
    (c) =>
      c.Nombre.toLowerCase().includes(texto) ||
      c.Correo.toLowerCase().includes(texto) ||
      (c.Ciudad ?? '').toLowerCase().includes(texto)
  )

  if (cargando) return <p>Cargando clientes...</p>
  if (error) return <p>{error}</p>

  return (
    <section>
      <h2>Listado de clientes</h2>
      <Buscador
        valor={busqueda}
        onCambio={setBusqueda}
        placeholder="Buscar por nombre, correo o ciudad..."
      />
      <p className="total">Mostrando {filtrados.length} de {clientes.length} clientes</p>
      <TablaClientes clientes={filtrados} />
    </section>
  )
}

export default Clientes
